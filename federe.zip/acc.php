
 <html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css.css">
	<link rel="stylesheet" type="text/css" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" />
	<title>ALB</title>

</head>
<body>

	<header class="header">
	
	<nav class="navbar">
		<ul>
		<li><a href="#acceuil" class="n">Acceuil</a></li>
		<li><a href="about.html" class="n">A Propos</a></li>
		<li><a href="evenement.html" class="n">Evenements</a></li>
		<li><a href="actualité.html" class="n">Actualités</a></li>
		<li><a  href="test.php"><input type="submit" name="sub" class="client" value="Acces Client"></a>
		</ul>
			</nav>
	<div class="fas fa-bars" id="menu"></div>
	</header>
		<div class="home">
			   <div class="tt">			<p>VOTRE BANQUE VIA LE WEB</p> </div>

    
</div>


	</div>
 	<section  class="serv" >
 		<div class="image">
 			<a href="#"><img class="img" src="serv1.jpeg"></a>
 			<div class="image-overlay">
 			<h3> Simple Client</h3>
 			</div>
 			
 		
 	</div>
 		<div class="image">
 			<a href="#"><img  class="img" src="serv2.jpg"></a>
 			<div class="image-overlay">
 			<h3>Entreprises</h3>
 			</div>
</div>
 			
 		
 	
 		<div class="image">
 			<a href="#"><img class="img" src="serv5.jpeg"></a>
 			<div class="image-overlay">
 				<h3>Promoteurs immobiliers </h3>
 			</div>
 		</div>
</section>
		<div class="presentation">
		<div class="row">
		<div class="imge">
	<img src="pres1.jpg">
	</div>
		<div class="text">
		<h1>QUI SOMME NOUS ?</h1>
		<p>Notre Bank, dotée d’une forte culture de développement et d’enrichissement du patrimoine immobilier tunisien, est incontestablement le premier établissement financier de l’habitat en Tunisie.
De ce fait, elle a considérablement contribué à l’accession d’un grand nombre de Tunisiens au logement. Pour ce faire, elle a mis en place une stratégie de proximité et d’ouverture à l’international, et ce en vue de servir le Tunisien là où il se trouve.</p>
		<a href="about.html" class="btn">EN SAVOIR PLUS</a>
</div>
</div>
</div>


	
 	
	<h1 class="heading">EVENEMENTS</h1>
	<section class="Realisations">
	<div class="image">
			<a href="#"><img class ="img" src="ev1.jpg"></a>
			<div class="image-overlay">
 			<h3>Salon Riyeda 2019</h3>
 			</div>
		</div>
		<div class="image">
		<a href="#"><img class ="img" src="ev2.jpg"></a>
			<div class="image-overlay">
 			<h3>Evènement Pole Conseil Financier 12-2018</h3>
 			</div>
		</div>
		<div class="image">
		<a href="#"><img class ="img" src="ev3.jpg"></a>
			<div class="image-overlay">
 			<h3>Conférence troubles du sommeil 10-2018</h3>
 			</div>
		</div>

	</section>
	<div class="bttn">
		<a href="evenement.html">Voir Touts Les Evenements</a></div>
	  <h1 class="heading">NOS DERNIÈRES ACTUALITES</h1>
	<section class="Realisations">
		<div class="image">
			<a href="#"><img class ="img" src="act1.jpg"></a>
			<div class="image-overlay">
 			<h3>soutenir la 12 ème édition des Foulées du Mégara</h3>
 			</div>
		</div>
		<div class="image">
		<a href="#"><img class ="img" src="act2.jpg"></a>
			<div class="image-overlay">
 			<h3>La Fondation œuvre pour le développement de la culture entrepreneuriale dans l’université</h3>
 			</div>
		</div>
		<div class="image">
		<a href="#"><img class ="img" src="act3.jpg"></a>
			<div class="image-overlay">
 			<h3>
Ouverture de la 206ème de notre agence  à El Amra</h3>
 			</div>
		</div>
		
	</section>

	<div class="bttn">
		<a href="actualité.html">Voir Toutes Les Actualités</a></div>

	<h1 class="heading">ILS NOUS ONT FAIT CONFIANCE</h1>
	<section class="tem">
  <div class="container">
    <div class="gauche"></div>
    <div class="droit">
      <div class="content">
        <h1>Une ingenieure en France</h1>
        <p> Étant non résidente en tunisie, j’ai été particulièrement impressionnée par la capacité de ALB à obtenir de très bonnes conditions pour cet emprunt. De plus le fait d’avoir seulement à fournir les documents et ensuite recevoir des propositions de différentes banques à choisir est un gros gain de temps et d’énergie !</p>
        
      </div>
    </div>
  </div>
</section>
	<section class="tem">
  <div class="container">
    <div class="gauche1"></div>
    <div class="droit">
      <div class="content">
        <h1>Le PDG d'Une entreprise internationale</h1>
        <p>Pour notre projet nous avons fait appel à ALB et nous sommes très satisfaits de vos services. Disponibilité, rapidité de réponses et conseils clairs et adaptés à notre niveau de connaissance du milieu bancaire. </p>
        
      </div>
    </div>
  </div>
</section>
      <footer>
	<div class="main-cont">
		<div class="left box">
			<h2>Nos Services</h2>
			<div class="cont">
				<ul>
				<li><a href="#">>>Simple Client</a></li>
				<li><a href="#">>>Entreprises</a></li>
				<li><a href="#">>>Promoteurs immobiliers </a></li>
				</ul>
			</div>
		</div>
<div class="center box">
	<h2>Adresse</h2>
	<div class="cont">
		<div class="place">
			<span class="fas fa-map-marker-alt"></span>
			<span>Sousse Tunisie</span>
		</div>
		<div class="phone">
			<span class="fas fa-phone-alt"></span>
			<span>50 000 000</span>
		</div>
		<div class="email">
			<span class="fas fa-envelope"></span>
			<a href="#"><span>BANK@gmail.com</span></a>
		</div>
	</div>
</div>
<div class="right box">
	<h2>Contactez-Nous</h2>
	<div class="cont">
		<form action="#">
			<div class="emaile">
				<div class="text">Email</div>
				<input type="email" required>
			</div>
			<div class="msg">
				<div class="text">Message</div>
				<textarea rows="2" cols="25" required></textarea>
			</div>
			<div >
				<a href="#" class="btn">Envoyer</a>
			</div>
		</form>
	</div>
</div>
	</div>

 <?php
      if (isset($erreur)){
         echo '<font color ="red" >' .$erreur. "</font>" ;
      }
      ?>
</footer>

</body>
</html>